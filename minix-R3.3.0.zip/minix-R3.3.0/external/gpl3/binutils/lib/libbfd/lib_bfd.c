/*	$NetBSD: lib_bfd.c,v 1.1 2009/08/18 20:21:59 skrll Exp $	*/

/* ELF systems need this to avoid the "wrong" libbfd.so. */
#include "libbfd.c"
